import React, { useState, useEffect } from 'react';
import '../ParentWebsiteCSS/TeacherClassSchedule.css';



const TeacherClassSchedule = () => {
  // Removed sidebar state
  const [viewMode, setViewMode] = useState('table'); // Toggle between 'table' and 'calendar'

  const scheduleData = [
    { id: 1, subject: "Mathematics 10", section: "Grade 10 - Einstein", days: ["M", "W", "F"], time: "08:00 AM - 09:00 AM", startTime: "08:00 AM", room: "Room 302", students: 42, color: "#cfe2ff" },
    { id: 2, subject: "Advanced Algebra", section: "Grade 11 - Newton", days: ["T", "TH"], time: "10:30 AM - 12:00 PM", startTime: "10:00 AM", room: "Lab 1", students: 35, color: "#d1e7dd" },
    { id: 3, subject: "Mathematics 10", section: "Grade 10 - Galileo", days: ["M", "W", "F"], time: "01:00 PM - 02:00 PM", startTime: "01:00 PM", room: "Room 302", students: 40, color: "#fff3cd" },
    { id: 4, subject: "Statistics", section: "Grade 12 - Pascal", days: ["T", "TH"], time: "02:00 PM - 03:30 PM", startTime: "02:00 PM", room: "Room 405", students: 38, color: "#f8d7da" },
  ];

  const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const timeSlots = ["08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM"];

  // Removed sidebar effect

  // Helper to find class for a specific calendar cell
  const getClassForSlot = (day, time) => {
    const dayInitial = day === "Thursday" ? "TH" : day.charAt(0);
    return scheduleData.find(cls => 
      cls.days.includes(dayInitial) && cls.startTime === time
    );
  };

  // Removed sidebarNav

  return (
    <div className="p-4 bg-soft-yellow">
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
          <h3 className="fw-bold text-dark mb-0">Class Schedule</h3>
          <p className="text-muted mb-0">Academic Year 2025-2026 | Second Semester</p>
        </div>
        <div className="btn-group shadow-sm bg-white rounded-3">
          <button 
              className={`btn ${viewMode === 'table' ? 'btn-dark' : 'btn-outline-dark'}`} 
              onClick={() => setViewMode('table')}>
              <i className="bi bi-table me-2"></i>Table
          </button>
          <button 
              className={`btn ${viewMode === 'calendar' ? 'btn-dark' : 'btn-outline-dark'}`} 
              onClick={() => setViewMode('calendar')}>
              <i className="bi bi-calendar-week me-2"></i>Calendar
          </button>
        </div>
      </div>
      {/* Stats Section */}
      <div className="row g-3 mb-4">
        <div className="col-md-4">
          <div className="card border-0 shadow-sm rounded-4 p-3 bg-white">
            <div className="d-flex align-items-center">
              <div className="rounded-circle bg-primary bg-opacity-10 p-3 me-3"><i className="bi bi-book text-primary fs-4"></i></div>
              <div><h6 className="text-muted mb-0">Total Classes</h6><h4 className="fw-bold mb-0">8 Classes</h4></div>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card border-0 shadow-sm rounded-4 p-3 bg-white">
            <div className="d-flex align-items-center">
              <div className="rounded-circle bg-success bg-opacity-10 p-3 me-3"><i className="bi bi-people text-success fs-4"></i></div>
              <div><h6 className="text-muted mb-0">Total Students</h6><h4 className="fw-bold mb-0">312 Students</h4></div>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card border-0 shadow-sm rounded-4 p-3 bg-white">
            <div className="d-flex align-items-center">
              <div className="rounded-circle bg-warning bg-opacity-10 p-3 me-3"><i className="bi bi-clock text-warning fs-4"></i></div>
              <div><h6 className="text-muted mb-0">Hours / Week</h6><h4 className="fw-bold mb-0">18 Hours</h4></div>
            </div>
          </div>
        </div>
      </div>
      {/* Dynamic Content View */}
      {viewMode === 'table' ? (
        <div className="card shadow-sm border-0 rounded-4 overflow-hidden bg-white">
          <div className="table-responsive">
            <table className="table table-hover mb-0 align-middle">
              <thead className="bg-dark text-white text-center">
                <tr>
                  <th className="py-3">Subject</th>
                  <th>Section</th>
                  <th>Days</th>
                  <th>Time</th>
                  <th>Room</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody className="text-center">
                {scheduleData.map((cls) => (
                  <tr key={cls.id}>
                    <td className="fw-bold text-primary">{cls.subject}</td>
                    <td><span className="badge bg-light text-dark border">{cls.section}</span></td>
                    <td>{cls.days.join('-')}</td>
                    <td>{cls.time}</td>
                    <td>{cls.room}</td>
                    <td><button className="btn btn-sm btn-outline-dark rounded-pill px-3">View Class</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card shadow-sm border-0 rounded-4 overflow-hidden bg-white">
          <div className="table-responsive">
            <table className="table table-bordered mb-0 calendar-table">
              <thead>
                <tr className="bg-light text-center">
                  <th style={{ width: '100px' }}>Time</th>
                  {daysOfWeek.map(day => <th key={day}>{day}</th>)}
                </tr>
              </thead>
              <tbody>
                {timeSlots.map(time => (
                  <tr key={time}>
                    <td className="text-center small fw-bold bg-light align-middle">{time}</td>
                    {daysOfWeek.map(day => {
                      const cls = getClassForSlot(day, time);
                      return (
                        <td key={day} style={{ height: '90px', verticalAlign: 'top', backgroundColor: cls ? cls.color : 'transparent' }}>
                          {cls && (
                            <div className="calendar-block p-1">
                              <div className="fw-bold small">{cls.subject}</div>
                              <div className="text-muted x-small">{cls.section}</div>
                              <div className="text-muted x-small">{cls.room}</div>
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeacherClassSchedule;