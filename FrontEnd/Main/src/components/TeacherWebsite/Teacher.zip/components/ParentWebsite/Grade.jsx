import React, { useState, useEffect } from 'react';
import '../ParentWebsiteCSS/Grade.css';

const navLinks = [
  { href: "index.jsx", icon: "bi-speedometer2", label: "Dashboard" },
  { href: "ClassSchedule.jsx", icon: "bi-calendar3", label: "Class Schedule" },
  { href: "Students.jsx", icon: "bi-people", label: "Students" },
  { href: "Grade.jsx", icon: "bi-pencil-square", label: "Grade Encode", active: true },
  { href: "AttendanceMonitoring.jsx", icon: "bi-check2-square", label: "Attendance Monitoring" },
  { href: "SPerformance.jsx", icon: "bi-graph-up-arrow", label: "Student Performance" },
  { href: "Message.jsx", icon: "bi-envelope", label: "Messages" },
];

const Grade = () => {
  // Removed sidebar state
  const [selectedClass, setSelectedClass] = useState("Grade 1 - Einstein");

  const classes = [
    "Grade 1 - Einstein", "Grade 2 - Newton", "Grade 3 - Galileo", 
    "Grade 4 - Pascal", "Grade 5 - Darwin", "Grade 6 - Atom"
  ];

  // Helper to generate 10 mock students per grade level
  const generateInitialGrades = () => {
    let allData = {};
    classes.forEach((grade) => {
      allData[grade] = Array.from({ length: 10 }, (_, i) => ({
        id: `LRN-2026-${grade.charAt(6)}-${i + 1}`,
        name: `Student ${i + 1} (${grade.split(' - ')[1]})`,
        written: 75 + (i % 5) * 3,
        performance: 80 + (i % 3) * 4,
        exam: 70 + (i % 4) * 5,
      }));
    });
    return allData;
  };

  const [gradeData, setGradeData] = useState(generateInitialGrades());

  const calculateFinal = (s) => Math.round((s.written * 0.3) + (s.performance * 0.5) + (s.exam * 0.2));
  const getRemarks = (avg) => avg >= 75 ? "PASSED" : "FAILED";

  const handleGradeChange = (grade, id, field, value) => {
    const numericValue = parseInt(value) || 0;
    setGradeData({
      ...gradeData,
      [grade]: gradeData[grade].map(s => s.id === id ? { ...s, [field]: numericValue } : s)
    });
  };

  // Removed sidebar effect

  const currentStudents = gradeData[selectedClass];

  // Removed sidebarNav

  return (
    <div className="p-4 bg-soft-yellow">
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4 gap-3">
        <div>
          <h2 className="fw-bold text-dark mb-1">Grade Encoding</h2>
          <p className="text-muted mb-0">Managing records for <span className="text-primary fw-bold">{selectedClass}</span></p>
        </div>
        <div className="d-flex gap-2">
          <select className="form-select border-0 shadow-sm w-auto" value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}>
            {classes.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <button className="btn btn-dark rounded-pill px-4 shadow-sm">
            <i className="bi bi-save me-2"></i>Save Changes
          </button>
        </div>
      </div>
      {/* Breakdown Section (Simplified) */}
      <div className="row g-3 mb-4">
        <div className="col-md-6 col-lg-3">
          <div className="card border-0 shadow-sm rounded-4 p-3 breakdown-card passing">
            <div className="text-muted small fw-bold">TOTAL PASSING</div>
            <h2 className="fw-bold text-success mb-0">{currentStudents.filter(s => calculateFinal(s) >= 75).length}</h2>
          </div>
        </div>
        <div className="col-md-6 col-lg-3">
          <div className="card border-0 shadow-sm rounded-4 p-3 breakdown-card failing">
            <div className="text-muted small fw-bold">TOTAL FAILING</div>
            <h2 className="fw-bold text-danger mb-0">{currentStudents.filter(s => calculateFinal(s) < 75).length}</h2>
          </div>
        </div>
      </div>
      {/* Grade Entry Table */}
      <div className="card shadow-sm border-0 rounded-4 overflow-hidden bg-white">
        <div className="table-responsive">
          <table className="table table-hover mb-0 align-middle text-center">
            <thead className="bg-dark text-white">
              <tr>
                <th className="py-3 px-4 text-start">Student Name</th>
                <th style={{width: '130px'}}>Written (30%)</th>
                <th style={{width: '130px'}}>Performance (50%)</th>
                <th style={{width: '130px'}}>Exam (20%)</th>
                <th>Final Grade</th>
                <th>Remarks</th>
              </tr>
            </thead>
            <tbody>
              {currentStudents.map((student) => {
                const final = calculateFinal(student);
                const remark = getRemarks(final);
                return (
                  <tr key={student.id}>
                    <td className="text-start ps-4">
                      <div className="fw-bold text-dark mb-0">{student.name}</div>
                      <div className="text-muted x-small">{student.id}</div>
                    </td>
                    <td><input type="number" className="grade-input" value={student.written} onChange={(e) => handleGradeChange(selectedClass, student.id, 'written', e.target.value)} /></td>
                    <td><input type="number" className="grade-input" value={student.performance} onChange={(e) => handleGradeChange(selectedClass, student.id, 'performance', e.target.value)} /></td>
                    <td><input type="number" className="grade-input" value={student.exam} onChange={(e) => handleGradeChange(selectedClass, student.id, 'exam', e.target.value)} /></td>
                    <td><span className={`fw-bold fs-5 ${final < 75 ? 'text-danger' : 'text-primary'}`}>{final}</span></td>
                    <td>
                      <span className={`badge rounded-pill ${remark === 'PASSED' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'}`}>
                        {remark}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Grade;