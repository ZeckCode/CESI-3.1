

  const Dashboard = () => {
    return (
      <div className="p-4 bg-soft-yellow">
        <header className="mb-4">
          <h2 className="fw-bold text-dark text-uppercase">Dashboard</h2>
        </header>
        {/* ...existing code... */}
        <div className="row g-4">
          {/* Notifications Column */}
          <div className="col-12 col-lg-8">
            <div className="card border-3 shadow-sm rounded-1 h-100">
              <div className="card-header bg-blue border-bottom py-3">
                <h6 className="mb-0 fw-bold">
                  <i className="bi bi-bell-fill me-2"></i>Notifications
                </h6>
              </div>
              <div className="card-body p-0">
                <div className="list-group list-group-flush rounded-1">
                  {/* Notification 1 */}
                  <div className="list-group-item list-group-item-action p-3 border-2 border-bottom">
                    <div className="d-flex w-100 justify-content-between align-items-center">
                      <div className="d-flex align-items-center">
                        <div className="icon-box bg-blue text-dark rounded-circle p-2 me-3">
                          <i className="bi bi-book"></i>
                        </div>
                        <div>
                          <h6 className="mb-0 fw-bold">Encoding of Grades</h6>
                          <small className="text-muted">Submission of Grades due at January 1, 2025 <span className="badge bg-light text-dark border"></span></small>
                        </div>
                      </div>
                      <small className="fw-bold text-primary">10:00 AM</small>
                    </div>
                  </div>

                  {/* Notification 2 */}
                  <div className="list-group-item list-group-item-action p-3 border-2 border-bottom">
                    <div className="d-flex w-100 justify-content-between align-items-center">
                      <div className="d-flex align-items-center">
                        <div className="icon-box bg-warning-subtle text-warning rounded-circle p-2 me-3 border border-warning">
                          <i className="bi bi-exclamation-triangle"></i>
                        </div>
                        <div>
                          <h6 className="mb-0 fw-bold">Library Notice</h6>
                          <small className="text-muted">The library will close early at 3:00 PM today.</small>
                        </div>
                      </div>
                      <small className="text-muted">10:30 AM</small>
                    </div>
                  </div>

                  {/* Notification 3 */}
                  <div className="list-group-item list-group-item-action p-3 border-2">
                    <div className="d-flex w-100 justify-content-between align-items-center">
                      <div className="d-flex align-items-center">
                        <div className="icon-box bg-success-subtle text-success rounded-circle p-2 me-3 border border-success">
                          <i className="bi bi-check-circle"></i>
                        </div>
                        <div>
                          <h6 className="mb-0 fw-bold">CESI Portal Updated</h6>
                          <small className="text-muted"><span className="fw-bold">CESI Portal</span> is now available. Thank you for waiting.</small>
                        </div>
                      </div>
                      <small className="text-muted">Yesterday</small>
                    </div>
                  </div>
                </div>
              </div>
              <div className="card-footer bg-white text-center border-2 py-2">
                <a href="#" className="small text-decoration-none text-primary fw-bold">View All Notifications</a>
              </div>
            </div>
          </div>

          {/* Announcements Column */}
          <div className="col-12 col-lg-4">
            <div className="card border-3 shadow-sm rounded-1 h-100 bg-white">
              <div className="card-header bg-danger text-white border-bottom py-3">
                <h6 className="mb-0 fw-bold"><i className="bi bi-megaphone-fill me-2"></i>Announcements</h6>
              </div>
              <div className="card-body p-0">
                <div className="list-group list-group-flush">
                  {/* Announcement 1 */}
                  <div className="list-group-item p-3 border-2 border-bottom">
                    <h6 className="mb-1 fw-bold text-danger">Library is now Open</h6>
                    <p className="small text-muted mb-0"><i className="bi bi-clock me-1"></i> 8:00 AM - 5:00 PM</p>
                  </div>
                  {/* Announcement 2 */}
                  <div className="list-group-item p-3 border-2 border-bottom">
                    <h6 className="mb-1 fw-bold text-dark">Enrollment Period</h6>
                    <p className="small text-muted mb-0">Second Semester enrollment starts on July 15.</p>
                  </div>
                  {/* Announcement 3 */}
                  <div className="list-group-item p-3 border-2">
                    <h6 className="mb-1 fw-bold text-dark">Uniform Policy</h6>
                    <p className="small text-muted mb-0">Full uniform is required starting Monday.</p>
                  </div>
                </div>
              </div>
              <div className="card-footer bg-white text-center border-2 py-2">
                <a href="#" className="small text-decoration-none text-danger fw-bold">See All Updates</a>
              </div>
            </div>
          </div>
        </div>
        {/* ...existing code... */}
        <div className="row mt-4">
          <div className="col-12">
            <div className="card border-3 shadow-sm rounded-4 bg-white overflow-hidden">
              <div className="card-header bg-blue border-bottom py-3">
                <h6 className="mb-0 fw-bold"><i className="bi bi-stars me-2"></i>ABOUT CESI</h6>
              </div>
              <div className="card-body">
                <div className="row align-items-center">
                  <div className="col-md-4 mb-3 mb-md-0">
                    <img src="/port.png" alt="Event" className="img-fluid rounded-3 shadow-sm" />
                  </div>
                  <div className="col-md-8">
                    <h5 className="fw-bold text-primary text-uppercase mb-3">What is CESI Portal</h5>
                    <p className="text-muted mb-3">
                      The CESI Portal is your all-in-one academic command center. Designed for efficiency and transparency, 
                      it allows students to seamlessly manage their educational journey. From monitoring real-time 
                      academic performance to tracking attendance and daily schedules, everything you need is organized 
                      into a single, user-friendly digital hub.
                    </p>
                    <div className="d-flex flex-wrap gap-2">
                      <span className="badge bg-blue text-dark px-3 py-2 rounded-pill">
                        <i className="bi bi-cpu me-1"></i> Real-time Data
                      </span>
                      <span className="badge bg-blue text-dark px-3 py-2 rounded-pill">
                        <i className="bi bi-person-heart me-1"></i> Student-First
                      </span>
                      <span className="badge bg-blue text-dark px-3 py-2 rounded-pill">
                        <i className="bi bi-shield-check me-1"></i> Secure Access
                      </span>
                      <span className="badge bg-blue text-dark px-3 py-2 rounded-pill">
                        <i className="bi bi-phone me-1"></i> Mobile Ready
                      </span>
                      <span className="badge bg-blue text-dark px-3 py-2 rounded-pill">
                        <i className="bi bi-clock me-1"></i> 24/7 Availability
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row mt-4">
          <div className="col-12">
            <div className="card border-3 shadow-sm rounded-4 bg-white overflow-hidden">
              <div className="card-header bg-blue border-bottom py-3">
                <h6 className="mb-0 fw-bold"><i className="bi bi-stars me-2"></i>Back to School</h6>
              </div>
              <div className="card-body">
                <div className="row align-items-center">
                  <div className="col-md-4 mb-3 mb-md-0">
                    <img src="/bsch.jpg" alt="Event" className="img-fluid rounded-3 shadow-sm" />
                  </div>
                  <div className="col-md-8">
                    <h5 className="fw-bold">Back to School</h5>
                    <p className="text-muted">Welcome back Students! Get ready for exciting events, schedules, and enjoy your school days!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  export default Dashboard;