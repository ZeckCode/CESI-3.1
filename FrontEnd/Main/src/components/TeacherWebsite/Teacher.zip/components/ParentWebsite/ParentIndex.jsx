import React from 'react';


import '../ParentWebsiteCSS/sidebar.css';
import Dashboard from './Dashboard.jsx';
import Grade from './Grade.jsx';
import AttendanceMonitoring from './AttendanceMonitoring.jsx';
import Message from './Message.jsx';
import TeacherClassSchedule from './TeacherClassSchedule.jsx';
import Students from './Students.jsx';
import SPerformance from './SPerformance.jsx';




const pages = [
  { key: 'dashboard', label: 'Dashboard', icon: 'bi-speedometer2', component: <Dashboard /> },
  { key: 'grade', label: 'Grade Encode', icon: 'bi-pencil-square', component: <Grade /> },
  { key: 'attendance', label: 'Attendance Monitoring', icon: 'bi-check2-square', component: <AttendanceMonitoring /> },
  { key: 'message', label: 'Messages', icon: 'bi-envelope', component: <Message /> },
  { key: 'schedule', label: 'Class Schedule', icon: 'bi-calendar3', component: <TeacherClassSchedule /> },
  { key: 'students', label: 'Students', icon: 'bi-people', component: <Students /> },
  { key: 'performance', label: 'Student Performance', icon: 'bi-graph-up-arrow', component: <SPerformance /> },
  { key: 'teacher-schedule', label: 'Teacher Schedule', icon: 'bi-calendar3', component: <TeacherClassSchedule /> },
];


function App() {
  const [activePage, setActivePage] = React.useState('dashboard');
  const [isCollapsed, setIsCollapsed] = React.useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [hoveredIdx, setHoveredIdx] = React.useState(null);

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsCollapsed(false);
      } else {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Sidebar nav content
  const sidebarNav = (
    <>
      <div className="profile-img-container mb-4 text-center">
        <div className="avatar-circle mx-auto mb-2">
          {isCollapsed ? <i className="bi bi-person"></i> : <span className="fw-bold">U</span>}
        </div>
        {!isCollapsed && <h6 className="mt-2 fw-bold">Username</h6>}
        {!isCollapsed && <small className="text-white-50">Faculty Member</small>}
      </div>
      <ul className="nav nav-pills flex-column mb-auto">
        {pages.map((item, idx) => (
          <li className="nav-item mb-2" key={item.key}>
            <button
              className={`nav-link w-100 text-start ${activePage === item.key ? 'active-link text-dark' : 'text-white'}${hoveredIdx === idx ? ' active-link' : ''}`}
              style={{ border: 'none', background: 'none', outline: 'none', cursor: 'pointer' }}
              onClick={() => setActivePage(item.key)}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
            >
              <i className={`bi ${item.icon} me-2`}></i>
              {!isCollapsed && item.label}
            </button>
          </li>
        ))}
      </ul>
      <button className="btn btn-danger btn-sm w-100 mt-auto d-flex align-items-center justify-content-center">
        <i className="bi bi-box-arrow-right"></i>
        {!isCollapsed && <span className="ms-2">Log out</span>}
      </button>
    </>
  );

  return (
    <div className="container-fluid p-0 d-flex flex-column flex-md-row min-vh-100">
      {/* --- Mobile Nav Bar(Hamburger) --- */}
      <div className="sidebar-mobile-header w-100 d-flex d-md-none">
        <button
          className="btn btn-link text-white p-0 me-2"
          aria-label="Open sidebar menu"
          onClick={() => setMobileMenuOpen(true)}
        >
          <i className="bi bi-list" style={{ fontSize: '2rem' }}></i>
        </button>
        <span className="fw-bold text-white">Student Portal</span>
        <span></span>
      </div>

      {/* --- Mobile Sidebar Drawer --- */}
      {mobileMenuOpen && (
        <>
          <div className="sidebar-mobile-backdrop" onClick={() => setMobileMenuOpen(false)}></div>
          <nav className="sidebar-mobile-menu open p-3 text-white">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <span className="fw-bold">Menu</span>
              <button className="btn btn-link text-white p-0" aria-label="Close sidebar menu" onClick={() => setMobileMenuOpen(false)}>
                <i className="bi bi-x-lg" style={{ fontSize: '1.5rem' }}></i>
              </button>
            </div>
            {sidebarNav}
          </nav>
        </>
      )}

      {/* --- Desktop Sidebar --- */}
      <nav
        className={`sidebar d-none d-md-flex flex-column p-3 text-white${isCollapsed ? ' collapsed' : ''}`}
        onMouseEnter={() => setIsCollapsed(false)}
        onMouseLeave={() => setIsCollapsed(true)}
      >
        {/* Toggle Button (desktop only) */}
        <button
          className="btn btn-sm mb-3 border-0 text-white d-none d-md-block align-self-end"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          <i className={`bi ${isCollapsed ? 'bi-list' : 'bi-chevron-left'}`} style={{ fontSize: '1.5rem' }}></i>
        </button>
        {sidebarNav}
      </nav>

      {/* Main Content Area */}
      <main className="flex-grow-1 p-4 bg-soft-yellow">
        {pages.find((p) => p.key === activePage)?.component}
      </main>
    </div>
  );
}

export default App;
